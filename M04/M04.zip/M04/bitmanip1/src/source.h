#ifndef AALTO_SIXBITS_H
#define AALTO_SIXBITS_H

unsigned char sixBits(unsigned char v);

#endif