#ifndef AALTO_COUNT_ALPHA_H_
#define AALTO_COUNT_ALPHA_H_

int count_isalpha(const char *str);

#endif //! AALTO_COUNT_ALPHA_H_
