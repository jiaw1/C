#ifndef _AALTO_COUNT_CHARS_H
#define _AALTO_COUNT_CHARS_H

void countchars(const char *array, unsigned int *counts);

#endif //! _AALTO_COUNT_CHARS_H
