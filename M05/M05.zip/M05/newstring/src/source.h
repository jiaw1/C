
void qstr_print(const char *s);
unsigned int qstr_length(const char *s);
const char *qstr_strstr(const char *str1, const char *str2);
int qstr_cat(char *dst, const char *src);
